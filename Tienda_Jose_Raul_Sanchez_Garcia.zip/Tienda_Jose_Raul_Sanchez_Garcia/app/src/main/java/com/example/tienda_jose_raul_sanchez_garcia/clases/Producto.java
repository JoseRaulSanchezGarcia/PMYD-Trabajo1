package com.example.tienda_jose_raul_sanchez_garcia.clases;

import java.io.Serializable;

public class Producto implements Serializable {
    //Atributos de clase
    public static final int COD_LIBRO_1 = 1;
    public static final int COD_LIBRO_2 = 2;
    public static final int COD_LIBRO_3 = 3;
    public static final int COD_AJEDREZ = 4;
    public static final int COD_MONOPOLY = 5;
    //Atributos de objeto
    private int codigo;
    private String nombre;
    private double precio;
    private int cantidad;
    //Métodos
    //Constructor por defecto
    public Producto(){}
    //Constructor por parámetros
    public Producto(int codigo, int cantidad){
        this.codigo = codigo;
        this.nombre = this.obtenerNombre();
        this.precio = this.calcularPrecio();
        this.cantidad = cantidad;
    }


    //Getters y setters
    public int getCodigo() {
        return codigo;
    }
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public double getPrecio() {
        return precio;
    }
    public void setPrecio(double precio) {
        this.precio = precio;
    }
    public int getCantidad() {
        return cantidad;
    }
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }


    public double getPrecioTotal(){
        double precioTotal = this.precio * this.cantidad;
        return precioTotal;
    }

    @Override
    public String toString() {
        return this.codigo + " - " + nombre + " - " + precio + "€ - " + cantidad;
    }




    //Métodos auxiliares
    private double calcularPrecio(){
        double precio = 0;
        switch(this.codigo){
            case COD_LIBRO_1:
                precio = 10.0;
                break;
            case COD_LIBRO_2:
                precio = 10.0;
                break;
            case COD_LIBRO_3:
                precio = 10.0;
                break;
            case COD_AJEDREZ:
                precio = 560.33;
                break;
            case COD_MONOPOLY:
                precio = 40.0;
                break;
        }
        return precio;
    }
    private String obtenerNombre(){
        String nombre = "";
        switch(this.codigo){
            case COD_LIBRO_1:
                nombre = "El Señor De Los Anillos: La Comunidad Del Anillo";
                break;
            case COD_LIBRO_2:
                nombre = "El Señor De Los Anillos: Las Dos Torres";
                break;
            case COD_LIBRO_3:
                nombre = "El Señor De Los Anillos: El Retorno Del Rey";
                break;
            case COD_AJEDREZ:
                nombre = "Ajedrez del Señor De Los Anillos";
                break;
            case COD_MONOPOLY:
                nombre = "Monopoly: El Señor De Los Anillos";
                break;
        }
        return nombre;
    }
}
