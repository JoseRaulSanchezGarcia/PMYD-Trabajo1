package com.example.tienda_jose_raul_sanchez_garcia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.tienda_jose_raul_sanchez_garcia.clases.Producto;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.TimeZone;

public class VentanaPago extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private Spinner spProductos;
    private ArrayList<Producto> listaProductos;
    private TextView txtCantidadPagoTotal;
    private TextView txtValorCodigoProducto;
    private TextView txtValorPrecioProducto;
    private TextView txtValorCantidadProducto;
    private TextView txtValorPrecioTotalProducto;
    private CheckBox cbTerminos;
    private EditText edtDireccion;
    private EditText edtFecha;
    private EditText edtHora;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ventana_pago);
        this.spProductos = (Spinner) findViewById(R.id.spProductos);
        this.txtCantidadPagoTotal = (TextView) findViewById(R.id.txtCantidadPagoTotal);
        this.txtValorCodigoProducto = (TextView) findViewById(R.id.txtValorCodigoProducto);
        this.txtValorPrecioProducto = (TextView) findViewById(R.id.txtValorPrecioProducto);
        this.txtValorCantidadProducto = (TextView) findViewById(R.id.txtValorCantidadProducto);
        this.txtValorPrecioTotalProducto = (TextView) findViewById(R.id.txtValorPrecioTotalProducto);
        this.cbTerminos = (CheckBox) findViewById(R.id.cbTerminos);
        this.edtDireccion = (EditText) findViewById(R.id.edtDireccion);
        this.edtFecha = (EditText) findViewById(R.id.edtFecha);
        this.edtHora = (EditText) findViewById(R.id.edtHora);
        //------------------------------------------------------------------------------------------
        Intent intent = getIntent();
        if(intent != null){
            this.listaProductos = (ArrayList<Producto>) intent.getSerializableExtra(VentanaEscaparate.EXTRA_PRODUCTOS);
        }else{
            this.listaProductos = new ArrayList<>();
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,R.layout.item_lista_productos,this.obtenerProductos(this.listaProductos));
        this.spProductos.setAdapter(adapter);
        this.spProductos.setOnItemSelectedListener(this);
        //------------------------------------------------------------------------------------------
        Calendar c = Calendar.getInstance();
        this.crearFecha(c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH));
        //------------------------------------------------------------------------------------------
        c = Calendar.getInstance(TimeZone.getTimeZone("Europe/Madrid"));
        this.crearHora(c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE));
    }
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if(this.txtCantidadPagoTotal.getText().toString().isEmpty()){
            this.calcularPrecioTotal();
        }
        //Producto p = this.listaProductos.get(position - 1);
        //Toast.makeText(this, "Posicion " + position, Toast.LENGTH_SHORT).show();
        Producto p = this.listaProductos.get(position);
        //Toast.makeText(this, "Precio " + p.getPrecio(), Toast.LENGTH_SHORT).show();
        this.txtValorCodigoProducto.setText(String.valueOf(p.getCodigo()));
        this.txtValorPrecioProducto.setText(String.valueOf(p.getPrecio()));
        this.txtValorCantidadProducto.setText(String.valueOf(p.getCantidad()));
        this.txtValorPrecioTotalProducto.setText(String.valueOf(p.getPrecioTotal()));
    }
    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        this.calcularPrecioTotal();
        Toast.makeText(this, "Selecciona un producto", Toast.LENGTH_SHORT).show();
    }
    public void pagar(View view){
        if(this.edtDireccion.getText().toString().isEmpty()){
            this.edtDireccion.setError("Introduzca una dirección");
            return;
        }
        if(this.cbTerminos.isChecked()){
            Toast.makeText(this, "Redireccionando a Paypal", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(this, "Para pagar debe aceptar los términos", Toast.LENGTH_SHORT).show();
        }
    }
    public void crearFecha(int year, int month, int dayOfMonth) {
        String textYear = String.valueOf(year);
        String textMonth = String.valueOf(month + 1);
        String textDay = String.valueOf(dayOfMonth);
        String textoFecha = textDay + "/" + textMonth + "/" + textYear;
        this.edtFecha.setText(textoFecha);
    }
    public void crearHora(int hourOfDay, int minute) {
        String textHour = String.valueOf(hourOfDay);
        String textMinute = String.valueOf(minute);
        String textoHoraFinal = textHour + ":" + textMinute;
        this.edtHora.setText(textoHoraFinal);
    }
    public void mostrarCalendario(View view){
        //Cargar el DatePicker
        DatePickerFragment calendario = new DatePickerFragment();
        //Mostrar el DatePicker
        calendario.show(getSupportFragmentManager(),"DatePicker");
    }
    public void mostrarReloj(View view){
        //Cargar el TimePicker
        TimePickerFragment reloj = new TimePickerFragment();
        //Mostrar el TimePicker
        reloj.show(getSupportFragmentManager(),"TimePicker");
    }



    //Métodos auxiliares
    private String[] obtenerProductos(ArrayList<Producto> listaProductos){
        String[] productos = new String[listaProductos.size()];
        if(listaProductos.size() > 0){
            for(int i = 0; i < listaProductos.size(); i++){
                productos[i] = listaProductos.get(i).getNombre();
            }
        }
        return productos;
    }
    private void calcularPrecioTotal(){
        double precioTotal = 0;
        for(Producto p : this.listaProductos){
            precioTotal += p.getPrecioTotal();
        }
        precioTotal += precioTotal * 0.21;
        this.txtCantidadPagoTotal.setText(String.valueOf(precioTotal));
    }

}