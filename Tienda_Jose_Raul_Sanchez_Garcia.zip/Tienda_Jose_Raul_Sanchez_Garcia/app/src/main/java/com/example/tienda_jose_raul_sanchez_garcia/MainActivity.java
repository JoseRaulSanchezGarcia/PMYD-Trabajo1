package com.example.tienda_jose_raul_sanchez_garcia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    private void irATwitter(View view){
        Uri urlWeb = Uri.parse("https://twitter.com/?lang=es");
        Intent intent = new Intent(Intent.ACTION_VIEW,urlWeb);
        startActivity(intent);
    }
    private void irAInstagram(View view){
        Uri urlWeb = Uri.parse("https://www.instagram.com/");
        Intent intent = new Intent(Intent.ACTION_VIEW,urlWeb);
        startActivity(intent);
    }
    private void irAFacebook(View view){
        Uri urlWeb = Uri.parse("https://www.facebook.com/?locale=es_ES");
        Intent intent = new Intent(Intent.ACTION_VIEW,urlWeb);
        startActivity(intent);
    }
    public void irARegistro(View view) {
        RadioButton rb = (RadioButton) view;
        if (rb.isChecked()) {
            int numRb = rb.getId();
            switch (numRb) {
                case R.id.rbTwitter:
                    this.irATwitter(view);
                    break;
                case R.id.rbInstagram:
                    this.irAInstagram(view);
                    break;
                case R.id.rbFacebook:
                    this.irAFacebook(view);
                    break;
            }
        }
    }
    public void irAEscaparate(View view){
        startActivity(new Intent(this,VentanaEscaparate.class));
    }
}