package com.example.tienda_jose_raul_sanchez_garcia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.tienda_jose_raul_sanchez_garcia.clases.Producto;

import java.util.ArrayList;

public class VentanaEscaparate extends AppCompatActivity {
    public static final String EXTRA_PRODUCTOS = "com.example.tienda_jose_raul_sanchez_garcia.VentanaEscaparate.listaProductos";
    private ImageView ivLibro1;
    private EditText edtCantidadLibro1;
    private Button bLibro1Mas;
    private Button bLibro1Menos;
    private ImageView ivLibro2;
    private EditText edtCantidadLibro2;
    private Button bLibro2Mas;
    private Button bLibro2Menos;
    private ImageView ivLibro3;
    private EditText edtCantidadLibro3;
    private Button bLibro3Mas;
    private Button bLibro3Menos;
    private ImageView ivAjedrez;
    private EditText edtCantidadAjedrez;
    private Button bAjedrezMas;
    private Button bAjedrezMenos;
    private ImageView ivMonopoly;
    private EditText edtCantidadMonopoly;
    private Button bMonopolyMas;
    private Button bMonopolyMenos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ventana_escaparate);
        this.ivLibro1 = (ImageView) findViewById(R.id.ivLibro1);
        this.edtCantidadLibro1 = (EditText) findViewById(R.id.edtCantidadLibro1);
        this.bLibro1Mas = (Button) findViewById(R.id.bLibro1Mas);
        this.bLibro1Menos = (Button) findViewById(R.id.bLibro1Menos);

        this.ivLibro2 = (ImageView) findViewById(R.id.ivLibro2);
        this.edtCantidadLibro2 = (EditText) findViewById(R.id.edtCantidadLibro2);
        this.bLibro2Mas = (Button) findViewById(R.id.bLibro2Mas);
        this.bLibro2Menos = (Button) findViewById(R.id.bLibro2Menos);

        this.ivLibro3 = (ImageView) findViewById(R.id.ivLibro3);
        this.edtCantidadLibro3 = (EditText) findViewById(R.id.edtCantidadLibro3);
        this.bLibro3Mas = (Button) findViewById(R.id.bLibro3Mas);
        this.bLibro3Menos = (Button) findViewById(R.id.bLibro3Menos);

        this.ivAjedrez = (ImageView) findViewById(R.id.ivAjedrez);
        this.edtCantidadAjedrez = (EditText) findViewById(R.id.edtCantidadAjedrez);
        this.bAjedrezMas = (Button) findViewById(R.id.bAjedrezMas);
        this.bAjedrezMenos = (Button) findViewById(R.id.bAjedrezMenos);

        this.ivMonopoly = (ImageView) findViewById(R.id.ivMonopoly);
        this.edtCantidadMonopoly = (EditText) findViewById(R.id.edtCantidadMonopoly);
        this.bMonopolyMas = (Button) findViewById(R.id.bMonopolyMas);
        this.bMonopolyMenos = (Button) findViewById(R.id.bMonopolyMenos);
    }
    public void incrementarCantidad(View view){
        String textoCantidad = "";
        switch(view.getId()){
            case R.id.bLibro1Mas:
                textoCantidad = this.edtCantidadLibro1.getText().toString();
                textoCantidad = this.incrementar(textoCantidad);
                this.edtCantidadLibro1.setText(textoCantidad);
                break;
            case R.id.bLibro2Mas:
                textoCantidad = this.edtCantidadLibro2.getText().toString();
                textoCantidad = this.incrementar(textoCantidad);
                this.edtCantidadLibro2.setText(textoCantidad);
                break;
            case R.id.bLibro3Mas:
                textoCantidad = this.edtCantidadLibro3.getText().toString();
                textoCantidad = this.incrementar(textoCantidad);
                this.edtCantidadLibro3.setText(textoCantidad);
                break;
            case R.id.bAjedrezMas:
                textoCantidad = this.edtCantidadAjedrez.getText().toString();
                textoCantidad = this.incrementar(textoCantidad);
                this.edtCantidadAjedrez.setText(textoCantidad);
                break;
            case R.id.bMonopolyMas:
                textoCantidad = this.edtCantidadMonopoly.getText().toString();
                textoCantidad = this.incrementar(textoCantidad);
                this.edtCantidadMonopoly.setText(textoCantidad);
                break;
        }
    }
    public void reducirCantidad(View view){
        String textoCantidad = "";
        switch(view.getId()){
            case R.id.bLibro1Menos:
                textoCantidad = this.edtCantidadLibro1.getText().toString();
                textoCantidad = this.reducir(textoCantidad);
                this.edtCantidadLibro1.setText(textoCantidad);
                break;
            case R.id.bLibro2Menos:
                textoCantidad = this.edtCantidadLibro2.getText().toString();
                textoCantidad = this.reducir(textoCantidad);
                this.edtCantidadLibro2.setText(textoCantidad);
                break;
            case R.id.bLibro3Menos:
                textoCantidad = this.edtCantidadLibro3.getText().toString();
                textoCantidad = this.reducir(textoCantidad);
                this.edtCantidadLibro3.setText(textoCantidad);
                break;
            case R.id.bAjedrezMenos:
                textoCantidad = this.edtCantidadAjedrez.getText().toString();
                textoCantidad = this.reducir(textoCantidad);
                this.edtCantidadAjedrez.setText(textoCantidad);
                break;
            case R.id.bMonopolyMenos:
                textoCantidad = this.edtCantidadMonopoly.getText().toString();
                textoCantidad = this.reducir(textoCantidad);
                this.edtCantidadMonopoly.setText(textoCantidad);
                break;
        }
    }
    public void irAPagar(View view){
        Intent intent = new Intent(this, VentanaPago.class);
        Producto p = new Producto();
        ArrayList<Producto> listaProductos = new ArrayList<>();
        String textoCantidad = this.edtCantidadLibro1.getText().toString();
        if(!textoCantidad.isEmpty() && !textoCantidad.equals("0")){
            p = new Producto(Producto.COD_LIBRO_1,Integer.valueOf(textoCantidad));
            listaProductos.add(p);
        }
        textoCantidad = this.edtCantidadLibro2.getText().toString();
        if(!textoCantidad.isEmpty() && !textoCantidad.equals("0")){
            p = new Producto(Producto.COD_LIBRO_2,Integer.valueOf(textoCantidad));
            listaProductos.add(p);
        }
        textoCantidad = this.edtCantidadLibro3.getText().toString();
        if(!textoCantidad.isEmpty() && !textoCantidad.equals("0")){
            p = new Producto(Producto.COD_LIBRO_3,Integer.valueOf(textoCantidad));
            listaProductos.add(p);
        }
        textoCantidad = this.edtCantidadAjedrez.getText().toString();
        if(!textoCantidad.isEmpty() && !textoCantidad.equals("0")){
            p = new Producto(Producto.COD_AJEDREZ,Integer.valueOf(textoCantidad));
            listaProductos.add(p);
        }
        textoCantidad = this.edtCantidadMonopoly.getText().toString();
        if(!textoCantidad.isEmpty() && !textoCantidad.equals("0")){
            p = new Producto(Producto.COD_MONOPOLY,Integer.valueOf(textoCantidad));
            listaProductos.add(p);
        }
        if(listaProductos.size() > 0){
            intent.putExtra(EXTRA_PRODUCTOS,listaProductos);
        }
        if(this.hayProductosSeleccionados()){
            startActivity(intent);
        }else{
            Toast.makeText(this, "Debe Seleccionar algún producto para poder comprarlo", Toast.LENGTH_LONG).show();
        }

    }



    //Métodos auxiliares
    private String incrementar(String textoCantidad){
        if(textoCantidad.isEmpty()){
            textoCantidad = "1";
        }else{
            int valor = Integer.valueOf(textoCantidad);
            valor++;
            textoCantidad = "" + valor;
        }
        return textoCantidad;
    }
    private String reducir(String textoCantidad){
        if(textoCantidad.isEmpty()){
            textoCantidad = "0";
        }else{
            int valor = Integer.valueOf(textoCantidad);
            if(valor > 0){
                valor--;
                textoCantidad = "" + valor;
            }
        }
        return textoCantidad;
    }
    private boolean hayProductosSeleccionados(){
        boolean losHay = false;
        String textoCantidad = this.edtCantidadLibro1.getText().toString();
        if(!textoCantidad.isEmpty() && !textoCantidad.equals("0")){losHay = true;}
        textoCantidad = this.edtCantidadLibro2.getText().toString();
        if(!textoCantidad.isEmpty() && !textoCantidad.equals("0")){losHay = true;}
        textoCantidad = this.edtCantidadLibro3.getText().toString();
        if(!textoCantidad.isEmpty() && !textoCantidad.equals("0")){losHay = true;}
        textoCantidad = this.edtCantidadAjedrez.getText().toString();
        if(!textoCantidad.isEmpty() && !textoCantidad.equals("0")){losHay = true;}
        textoCantidad = this.edtCantidadMonopoly.getText().toString();
        if(!textoCantidad.isEmpty() && !textoCantidad.equals("0")){losHay = true;}
        return losHay;
    }
}